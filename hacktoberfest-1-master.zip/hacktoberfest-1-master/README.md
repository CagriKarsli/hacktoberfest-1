# hacktoberfest

1. After you've learnt Github, open a pull-request here.
2. In a `your_username.txt` file, where you replace your username, write why you love open source.
3. We'll accept it. <3
